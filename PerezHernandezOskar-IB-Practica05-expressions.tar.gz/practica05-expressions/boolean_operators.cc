/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 19 2024
* @brief Boolean operators
*        Practica 5
*        Muestra los diferentes operadores booleanos
*/

#include <iostream>

int main() {
  bool a, b;
  std::cout << "a b   and or !a !b\n";

  for (int i = 0; i < 2; i++) {
    for (int j = 0; j < 2; j++) {
      a = i;
      b = j;
      std::cout << a << " ";
      std::cout << b << "    ";

      std::cout << (a && b) << "  ";
      std::cout << (a || b) << "  ";
      std::cout << (!a) << "  ";
      std::cout << (!b) << "  " << std::endl;
    }
  }
  return 0;
}
