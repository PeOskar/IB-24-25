/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 19 2024
* @brief Operadores Aritmeticos
*        Muestra los diferentes operadores de c++
*/


#include <iostream>

int main() {
  double num1{7}, num2{3};
  
  std::cout << num1 << " + " << num2 << " = " << num1 + num2 << std::endl;
  std::cout << num1 << " - " << num2 << " = " << num1 - num2 << std::endl;
  std::cout << num1 << " * " << num2 << " = " << num1 * num2 << std::endl;
  std::cout << num1 << " / " << num2 << " = " << num1 / num2 << std::endl;
  std::cout << num1 << " % " << num2 << " = " << static_cast<int>(num1) %
    static_cast<int>(num2) << std::endl;
  std::cout << num1 << " == " << num2 << " = " << (num1 == num2) << std::endl;
  std::cout << num1 << " != " << num2 << " = " << (num1 != num2) << std::endl;
  std::cout << num1 << " > " << num2 << " = " << (num1 > num2) << std::endl;
  std::cout << num1 << " < " << num2 << " = " << (num1 < num2) << std::endl;
  std::cout << num1 << " >= " << num2 << " = " << (num1 >= num2) << std::endl;
  std::cout << num1 << " <= " << num2 << " = " << (num1 <= num2) << std::endl;
  return 0;
}
