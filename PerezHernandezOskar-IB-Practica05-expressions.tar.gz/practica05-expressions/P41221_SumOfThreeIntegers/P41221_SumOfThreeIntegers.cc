/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 24 2024
* @brief SumOfThreeIntegers
*        P41221
*        Print the sum of three integers
*/


#include <iostream>

int main() {
  int number1, number2, number3;
  std::cin >> number1 >> number2 >> number3;
  std::cout << number1 + number2 + number3 << std::endl;
  return 0;
}

