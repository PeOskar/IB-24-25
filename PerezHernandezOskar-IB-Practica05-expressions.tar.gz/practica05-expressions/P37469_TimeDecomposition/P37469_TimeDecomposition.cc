/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 24 2024
* @brief Time Decomposition
*        P37469
*        Converts seconds to hours, minutes and seconds
*/

#include <iostream>

int main() {
  int hours{0}, minutes{0}, seconds{0};
  const int seconds_per_hour{3600}, seconds_per_minute{60};
  std::cin >> seconds;
  hours = seconds / seconds_per_hour;
  seconds = seconds - (hours * seconds_per_hour);
  minutes = seconds / seconds_per_minute;
  seconds = seconds - (minutes * seconds_per_minute);
  std::cout << hours << ' ' << minutes << ' ' << seconds << std::endl;
  return 0;
}
