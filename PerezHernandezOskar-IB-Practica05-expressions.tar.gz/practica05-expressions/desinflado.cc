/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 19 2024
* @brief Desinflado
*        Practica 5
*        Pasar de minuscula a mayuscula
*/

#include <iostream>

int main() {
  char letra, mayuscula;
  std::cin >> letra;
  mayuscula = static_cast<char>(static_cast<int>(letra) + 32);
  std::cout << mayuscula << std::endl;
  return 0;
}
