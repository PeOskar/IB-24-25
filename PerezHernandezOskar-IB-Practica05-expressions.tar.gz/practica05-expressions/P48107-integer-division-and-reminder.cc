/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 23 2024
* @brief Integer division
*        P70955 
*/


#include <iostream>

int main() {
  unsigned int numerador, denominador;
  std::cin >> numerador >> denominador;
  if (denominador == 0) {
    return 1;
  }

  int division = numerador / denominador;
  int resto = numerador % denominador;

  std::cout << division << ' ' << resto << std::endl;
  return 0;
}
