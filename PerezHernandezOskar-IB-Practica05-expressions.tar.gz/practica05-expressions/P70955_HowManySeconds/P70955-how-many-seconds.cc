/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica
*
* @author Oskar J. Pérez Hdez
* @date Oct 24 2024
* @brief How many seconds
*        P70955
*        converts years, days, hours, minutes and seconds to seconds
*/

#include <iostream>

int main() {
  int years{0}, days{0}, hours{0}, minutes{0}, seconds{0};
  std::cin >> years >> days >> hours >> minutes >> seconds;
  std::cout << (years * 365 * 24 * 60 * 60) + (days * 24 * 60 * 60) + (hours *
    60 * 60) + (minutes * 60) + seconds << std::endl;
  return 0;
}
